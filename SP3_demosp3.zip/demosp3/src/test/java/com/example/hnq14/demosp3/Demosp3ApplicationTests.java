package com.example.hnq14.demosp3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demosp3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
