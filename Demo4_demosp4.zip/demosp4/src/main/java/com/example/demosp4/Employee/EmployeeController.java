package com.example.demosp4.Employee;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
    @Autowired
    private EmployeeRepository employeeRepository;
    //lay danh sach cua cac nhan vien
    @GetMapping
    public List<Employee> getAllEmployees(){
        return employeeRepository.findAll();
    }
    //lay thong tin nhan vien theo id
    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id){
        Optional<Employee> employee= employeeRepository.findById(id);
        return employee.map(ResponseEntity::ok).orElseGet(()-> ResponseEntity.notFound().build());
    }
    //loc nhan vien co muc luong cao hon 5000
    @GetMapping("/high-salary")
    public List<Employee> getEmployeeWithHighSalary(){
        return employeeRepository.findAll()
        .stream()
        .filter(emp->emp.getSalary()>5000)
        .collect(Collectors.toList());
    }
    //them nhan vien moi
    @PostMapping
    public Employee creaEmployee(@RequestBody Employee employee){
        //ham nay co van de a:
        //--
        //---
        return employeeRepository.save(employee);
    }
    //cap nhat
    @PutMapping("/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable Long id,
    @RequestBody Employee newEmployeeData){
        return employeeRepository.findById(id)
        .map(emp->{
            emp.setName(newEmployeeData.getName());
            emp.setAge(newEmployeeData.getAge());
            emp.setDepartment(newEmployeeData.getDepartment());
            emp.setSalary(newEmployeeData.getSalary());
            return ResponseEntity.ok(employeeRepository.save(emp));
        })
        .orElseGet(()->ResponseEntity.notFound().build());
    }
    //xoa
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable Long id){
        if(employeeRepository.existsById(id)){
            employeeRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        else {
            return ResponseEntity.notFound().build();
        }
    }
}
