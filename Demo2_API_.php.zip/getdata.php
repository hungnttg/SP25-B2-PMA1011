<?php
//khai bao thong tin key noi csdl
$s="localhost"; $u="root";$p="";$db="a7";
//thuc hien ket noi
$conn = new mysqli($s,$u,$p,$db);
//thuc thi lenh
$result = $conn->query("select * from mytable");
//doc ket qua
while($row[]=$result->fetch_assoc())//do tung dung
{
    $json = json_encode($row);//chuyen sang json
}
echo '{"products":'.$json.'}';