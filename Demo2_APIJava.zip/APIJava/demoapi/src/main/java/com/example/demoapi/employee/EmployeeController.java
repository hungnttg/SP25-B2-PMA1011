package com.example.demoapi.employee;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
    @Autowired
    private EmployeeRepository employeeRepository;
    @GetMapping("/high-salary")
    public List<Employee> getEmployeesWithHighSalary(){
        return employeeRepository.findAll()
        .stream()
        .filter(nv->nv.getSalary()>5000)
        .collect(Collectors.toList());
    }
}
